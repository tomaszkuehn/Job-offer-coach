@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" -InstallDir "%LOCALAPPDATA%\GEM"
pause
