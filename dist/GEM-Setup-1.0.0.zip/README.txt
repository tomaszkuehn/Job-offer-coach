# AI Chat — Job Offers

A web application for preparing job offers with the help of an AI model in the cloud (Ollama Cloud). Runs in the browser; the backend is Node.js + Express.

## License

Attribution-Required **Non-Commercial No-Derivatives** (`AN-NC-ND`, custom, CC BY-NC-ND-inspired — see `LICENSE`):

- ✅ Free to **use** and **redistribute verbatim** for non-commercial purposes
- ✋ **Attribution always required** — visible credit: *Tomasz Kuehn, "AI Chat — Job Offers"*
- 🚫 **No modifications** — redistribution of the original, unmodified code only
- 🚫 **No commercial use** — commercial licensing on request: tomasz.kuehn@gmail.com

## Features

- **Chat with an AI model** — enter a job offer description and get tailored interview prep, positioning advice, and answers grounded in your documents. Context grows with each exchange (full history is sent to the model).
- **Streaming responses** — answers appear live, token-by-token, with incremental markdown rendering (marked.js) and a model badge on each response.
- **Model configuration** — multiple named model slots (endpoint, API key, model id, per-model prompt); the model catalogue can be fetched live from the provider (`/api/tags`), so switching models is a config change, not a code change.
- **RAG files (no embeddings)** — TXT/MD/PDF files attached as text to every request. Files are **content-addressed** (see below) and attached **per conversation**.
- **Preview before sending** — an overlay showing the full payload (system prompt + RAG files + history), with the option to block the request.
- **Conversations** — save, rename, and restore from history. A new conversation keeps the RAG selection and model; the current conversation is highlighted in green on the list, and browsing archives does not reorder the list (ordering is by last *content* change, not last access).
- **Bulk analysis** — pick one or more offer files (the **CSV export** from the LinkedIn extension options page — `linkedin-jobs.csv` with `jobId,title,company,location,workplaceType,url,status,savedAt,descriptionText` headers, or the legacy `job.txt`: full LinkedIn HTML snapshots, one or many offers per file, or the plain-text "copy" format `title / company / location / url / --- / description`), tick the offers to process, and GEM automatically creates a conversation per offer with the **RAG file set of the latest conversation**, sends the offer, waits for the full reply, renames the conversation to `Company — Position`, and extracts the **METRYKA** block (interview / employment / role fit / satisfaction / salary / recommend %) into `data/metrics.json`. A failed offer deletes its conversation and is retried once; a second failure skips it. Progress is streamed per offer (NDJSON) and shown as status chips in the dialog. Offers already analyzed in stored conversations (≥ 70 % similarity, same algorithm as the preview warning) are **highlighted in yellow and unchecked by default**, with a "Already analyzed in: …" badge. Each row shows the CSV `Status` value as a chip (apply / applied / to-consider / german / ignored); clicking the row body opens a **full offer preview** (Esc / ✕ / backdrop closes).
- **Metrics view** — a "Metrics" button lists all saved metrics sorted by the *Recommend* score (best first); clicking a row opens the conversation the metric came from.
- **Backup & restore** — a "Backup & restore" button downloads a ZIP of the whole `data/` directory (config incl. API keys, conversations, RAG files, metrics); restoring from a ZIP (with confirmation) wipes and replaces the current data.
- **Live context-size indicator** — a badge next to the model switcher shows the estimated context size in kB (green / yellow / red thresholds) so cost and limit pressure are visible before sending.

## Content-addressed RAG files

Every uploaded file is stored under a name derived from its content:
`<first 8 chars of SHA-256>_<clean original name>`, e.g.
`ba15a635_CV_Tomasz_Kuehn_extracted.txt`.

Consequences:

- **No duplicates** — uploading the same content again (even under a different filename) does not store a second copy; the existing file is attached ("reused") to the current conversation instead.
- **Immutable versions** — a changed document gets a new hash, so it becomes a new file; older conversations keep referencing the exact version they were created with. Their context never changes retroactively.
- **Shared storage** — files live in a single `data/uploads/` pool; conversations store only the list of file names.

The RAG list in the UI shows **only the files attached to the current conversation**.

## Requirements

- Node.js 18+ (uses the global `fetch`)
- [pandoc](https://pandoc.dev) on PATH — only for the ODT export feature

## Installation and running

```bash
npm install
npm start
```

Open in your browser: http://localhost:3000

### Auto-start with tray icon

`tray-app.ps1` runs at Windows logon (hidden window, shortcut in `shell:startup\GEM Tray.lnk`). The tray icon shows the server state — green = running, red = stopped (checked every 5 s). Left-click opens the app; right-click menu: **Open GEM / Start – Restart server / Stop server / Exit tray**. If the server is not running at logon, the script starts it. A mutex (`GEMTrayLauncher`) prevents duplicate tray instances.

The tray locates `node.exe` via `PATH`, standard install locations, and nvm setups (`NVM_SYMLINK`, `NVM_HOME`, `%APPDATA%\nvm`, `%LOCALAPPDATA%\Author Software\nvm`, plus a recursive scan of nvm version dirs as a last resort). Diagnostics are logged to `%TEMP%\GEM-tray.log`.

## Configuration

In the sidebar:

1. **Model configuration**
   - **Endpoint** — defaults to `https://ollama.com/api/chat` (Ollama Cloud API)
   - **API key** — your Ollama Cloud key (from https://ollama.com/settings/keys)
   - **Model** — e.g. `deepseek-v4-flash:0731` (or use **Fetch models** to pick from the live catalogue)
2. **Expected response (prompt)** — instructions for the model on how to phrase the response.
3. **Files (RAG)** — upload files to attach them to the current conversation.

Click **Save configuration** (the button pulses red when there are unsaved changes).

## Usage

1. Enter a job offer description in the chat field and click **Send**.
2. A **preview** of the full content that will be sent to the model appears.
   - **Send to model** — continues.
   - **Cancel / ✕** — blocks the request (the message stays in history; you can edit and resend it).
3. The model's response **streams in live** with markdown rendering. Continue the conversation — the context grows.

### Conversations

- **+ New conversation** — asks for a name for the conversation being closed, but **only when it still carries the default `Conversation` name** (already-renamed conversations keep their name untouched and the new one starts immediately). The new one starts with the default `Conversation` name (the creation date/time shown on the list is generated separately), keeping the RAG selection and model.
- Clicking a name in the list **restores** the conversation together with its RAG files. The browsed conversation stays in place on the list and is highlighted in green.
- The list is **scrollable** (fixed height) and has a **search box**: matching
  covers conversation **titles** and **message contents** — body matches show
  a snippet under the name. **Esc** clears the search.
- **✎** renames, **✕** deletes a conversation. Renaming opens an in-app dialog:
  you edit only the name — the creation date and time shown below the name on
  the list are managed by the app and are never part of the editable name.
  Each list entry displays the conversation's **creation date and time**
  (`dd/mm/yyyy, hh:mm`) under the name.
- **🏷 tags** — each conversation can carry optional tags shown as badges on
  the list: **match probability** (interview chance, %), **German requirement**
(`DE required` / `no DE`), and the application status (**to apply** /
**applied** / **not applying**). Open the tag editor with the 🏷 button and
either fill the fields manually or press **Suggest from content** — the server
scans the conversation for the newest interview-chance percentage, German
requirement statements, and "applied" / "don't apply" verdicts.
- A model response keeps **streaming in the background** when you switch to another conversation (or start a new one) — when the stream finishes, the reply is appended to the conversation it belongs to and saved automatically.
- The **preview overlay** is keyboard-driven: **Enter** sends, **Esc** cancels.
- **Duplicate-offer warning** — when the submitted message resembles the first message of an already-analyzed conversation (≥ 70 % similarity), the preview shows a warning listing those conversations with their match percentages. The send itself is never blocked. Similarity takes the **max** of whole-text token overlap (Jaccard) and **5-word-sequence containment**, so offers with a different header/intro (same body from another source) are still caught.

### Exporting CV & Cover Letters (ODT)

When the model produces an application package (CV + cover letter sections),
the sidebar button **"Export CV & Cover Letter (ODT)"** extracts the sections
and converts them to OpenDocument Text with **pandoc** (requires `pandoc`
on PATH).

- **Section detection is format-tolerant**: numbered headings (`### 4a.`, `4b.`, `4c.`),
  natural-language headings on H2–H4 (`## CV (English…)`, `### Cover Letter (EN)`,
  `## Anschreiben (Deutsch…)`), and standalone CV regeneration messages
  (`# Tomasz Kuehn …`, also inside a ```markdown fence) are all recognized.
- Each part is taken from the **latest** assistant message containing it —
  a full package, a partial package update, or a standalone CV regeneration
  all count, so the newest version always wins.
- **File names** follow `<conversation>_<CV | cover | Anschreiben>.odt` —
  e.g. `RWE_CV.odt`, `RWE_cover.odt` (English letter), `RWE_Anschreiben.odt`
  (German letter).
  Re-exporting **unchanged** content reuses the existing file (content-hash
  manifest keyed by conversation ID — stable across renames). Export always
  reads **only the current conversation**.
- **Partial-failure handling**: if a document cannot be written (e.g. the file
  is open in LibreOffice), the export retries once under a timestamped
  alternative name; the UI reports which parts succeeded, which failed, and
  suggests closing the file and re-exporting.
- Output goes to `moje_dok/odt/` ("moje dokumenty" = *my documents* — Polish
  folder name kept for local continuity); styling comes from a bundled reference
  document (`tools/reference-calibri.odt`): Calibri body font with Calibri Light
  headings, 10.5 pt base size, compact paragraph spacing, table borders (pandoc emits
  borderless tables — the server patches them in), single-line horizontal
  rules, **no page numbers** (empty footer), and `—`/`–` converted to plain `-`.

## Project structure

```
.
├── server.js                      # Express backend: config, CAS files, conversations, streaming proxy, ODT export
├── package.json
├── tools/
│   ├── extract-package.js         # CLI version of the package export (pandoc)
│   └── reference-calibri.odt      # Pandoc reference doc: Calibri fonts, sizes, spacing, HR style
├── public/
│   └── index.html                 # Frontend (single file: config panel + chat UI)
├── moje_dok/                      # Local output ("my documents", git-ignored)
│   └── odt/                       # Exported CV / cover letter files + per-conversation manifests
└── data/                          # Created automatically
    ├── config.json                # Model slots, active model, system prompt
    ├── uploads/                   # Content-addressed RAG file pool
    ├── conversations.json         # Conversations index (ordered by last content change)
    ├── conversations/<id>/        # Saved conversations (messages + selectedFiles)
    └── .cas-migrated              # One-time legacy→CAS migration flag
```

## API

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/config` | Get configuration and file list |
| POST | `/api/config` | Save configuration |
| POST | `/api/files` | Upload files (multipart); identical content is deduplicated and returned as `reused` |
| DELETE | `/api/files/:name` | Delete a file (detaches it from all conversations) |
| POST | `/api/preview` | Build the payload for preview (without sending) |
| POST | `/api/chat` | Send messages to the model (non-streaming) |
| POST | `/api/chat/stream` | Streaming chat: proxies upstream NDJSON, emits plain-text chunks, model name in the `X-Model` header |
| POST | `/api/context-size` | Estimate context size (chars + tokens) for the current selection |
| GET | `/api/conversations` | List conversations |
| GET | `/api/conversations/search?q=` | Search conversations by title or message content (returns index entries with `matchType` and `snippet` for body matches) |
| GET | `/api/conversations/:id` | Get a conversation (read-only; does not touch global config) |
| POST | `/api/conversations` | Create or update a conversation (`id` optional); bumps `updatedAt` only when content changes |
| POST | `/api/conversations/:id/rename` | Rename a conversation |
| POST | `/api/conversations/:id/tags` | Set conversation tags (`{ matchPct, german, status }`; `matchPct` 0–100 or `null`, `german` = `required` / `not_required` / `null`, `status` = `to_apply` / `applied` / `not_applying` / `null`) |
| POST | `/api/conversations/:id/tags/analyze` | Suggest tags from conversation content (does not save) |
| DELETE | `/api/conversations/:id` | Delete a conversation |
| POST | `/api/export-package` | Extract CV + cover letters from the latest package in a conversation and convert them to ODT (`{ conversationId }`); returns `207` with a `failed` list on partial success |
| POST | `/api/bulk/parse` | Parse an uploaded offer file (multipart `file`; CSV export / HTML snapshots / plain text); returns `{ offers: [{ title, company, location, url, description }] }` |
| POST | `/api/bulk/run` | Run bulk analysis (`{ offers, modelIndex }`); NDJSON progress events `start` / `offer-start` / `offer-done` / `offer-failed` / `done` |
| GET | `/api/metrics` | All saved METRYKA entries, sorted by `recommend` (desc) |
| DELETE | `/api/metrics/:convId` | Delete the metric entry of a conversation |
| GET | `/api/backup` | Download a ZIP of the whole `data/` directory (config incl. API keys, conversations, RAG files, metrics) with a `gem-backup.json` manifest |
| POST | `/api/restore` | Restore from a backup ZIP (multipart `file`); requires the `gem-backup.json` manifest, wipes and replaces all current data |

Chat requests (`preview`, `chat`, `chat/stream`, `context-size`) accept
`{ messages, modelIndex, selectedFiles, conversationId }` — the RAG file
selection travels with each request, so the server stays stateless.

## Notes

- RAG files are attached as plain text to the prompt (no embeddings/vectors) — the right trade-off when the corpus is a handful of personal documents.
- The API key is stored locally in `data/config.json` — do not share this file. Keys are never exposed to the frontend; all provider calls are proxied through the backend.
- The app runs locally; it is not intended for public deployment without security measures.